<?php

namespace App\Models;

/**
 * SmsVerify Model
 */
class SmsVerify extends Model
{
    protected $connection = 'default';
    protected $table = 'sms_verify';
}
